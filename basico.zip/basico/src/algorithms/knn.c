#include "knn.h"
#include <stdlib.h>
#include <float.h>
#include <math.h>

KNNClassifier* knn_create(int k) {
    // TODO: Implementar la creación del clasificador KNN
    // 1. Asignar memoria para la estructura
    // 2. Inicializar el valor de k
    // 3. Inicializar X_train y y_train como NULL
    // 4. Devolver el clasificador creado
    return NULL; // Reemplazar con la implementación
}

void knn_fit(KNNClassifier* knn, Matrix* X, Matrix* y) {
    // TODO: Implementar el entrenamiento del clasificador
    // 1. Almacenar los datos de entrenamiento (X)
    // 2. Almacenar las etiquetas (y)
    // Nota: Puede ser útil simplemente guardar las referencias
}

Matrix* knn_predict(KNNClassifier* knn, Matrix* X) {
    // TODO: Implementar la predicción
    // 1. Crear matriz para almacenar las predicciones
    // 2. Para cada muestra en X:
    //    a. Calcular distancias a todas las muestras de entrenamiento
    //    b. Encontrar los k vecinos más cercanos
    //    c. Determinar la clase mayoritaria entre esos vecinos
    //    d. Asignar esa clase como predicción
    // 3. Devolver matriz con las predicciones
    return NULL; // Reemplazar con la implementación
}

void knn_free(KNNClassifier* knn) {
    // TODO: Implementar la liberación de memoria
    // 1. Liberar matrices internas si es necesario
    // 2. Liberar la estructura principal
}
