#include "linear_regression.h"
#include <stdlib.h>
#include <math.h>

LinearRegression* linear_regression_create(double learning_rate, int max_iterations, double tolerance) {
    // TODO: Implementar la creación del modelo de regresión lineal
    // 1. Asignar memoria para la estructura
    // 2. Inicializar parámetros (learning_rate, max_iterations, tolerance)
    // 3. Inicializar weights como NULL y bias como 0
    // 4. Devolver el modelo creado
    return NULL; // Reemplazar con la implementación
}

int linear_regression_fit(LinearRegression* model, Matrix* X, Matrix* y) {
    // TODO: Implementar el algoritmo de descenso de gradiente
    // 1. Inicializar pesos (weights) con valores pequeños aleatorios
    // 2. Repetir hasta convergencia o max_iterations:
    //    a. Calcular predicciones: y_pred = X * weights + bias
    //    b. Calcular error: error = y_pred - y
    //    c. Calcular gradientes: 
    //       - grad_w = (X^T * error) / n_samples
    //       - grad_b = sum(error) / n_samples
    //    d. Actualizar pesos: weights = weights - learning_rate * grad_w
    //    e. Actualizar sesgo: bias = bias - learning_rate * grad_b
    //    f. Verificar convergencia (cambio en error < tolerance)
    // 3. Devolver 1 si éxito, 0 si error
    return 0; // Reemplazar con la implementación
}

Matrix* linear_regression_predict(LinearRegression* model, Matrix* X) {
    // TODO: Implementar la predicción
    // 1. Crear matriz para almacenar las predicciones
    // 2. Calcular y_pred = X * weights + bias
    // 3. Devolver matriz con las predicciones
    return NULL; // Reemplazar con la implementación
}

double linear_regression_mse(LinearRegression* model, Matrix* X, Matrix* y) {
    // TODO: Implementar el cálculo del error cuadrático medio
    // 1. Calcular predicciones
    // 2. Calcular diferencias al cuadrado entre predicciones y valores reales
    // 3. Calcular promedio de las diferencias al cuadrado
    return -1.0; // Reemplazar con la implementación
}

double linear_regression_r2_score(LinearRegression* model, Matrix* X, Matrix* y) {
    // TODO: Implementar el cálculo del coeficiente de determinación R²
    // 1. Calcular predicciones
    // 2. Calcular varianza total: sum((y - y_mean)²)
    // 3. Calcular varianza residual: sum((y - y_pred)²)
    // 4. Calcular R² = 1 - (varianza residual / varianza total)
    return -1.0; // Reemplazar con la implementación
}

void linear_regression_free(LinearRegression* model) {
    // TODO: Implementar la liberación de memoria
    // 1. Liberar matriz de pesos
    // 2. Liberar la estructura principal
}
