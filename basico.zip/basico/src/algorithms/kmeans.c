#include "kmeans.h"
#include <stdlib.h>
#include <float.h>
#include <math.h>

KMeans* kmeans_create(int k) {
    // TODO: Implementar la creación del modelo K-Means
    // 1. Asignar memoria para la estructura
    // 2. Inicializar el número de clusters (k)
    // 3. Inicializar centroids como NULL
    // 4. Devolver el modelo creado
    return NULL; // Reemplazar con la implementación
}

int kmeans_fit(KMeans* model, Matrix* X, int max_iter, double tol) {
    // TODO: Implementar el algoritmo K-Means
    // 1. Inicializar centroides aleatoriamente a partir de los datos
    // 2. Repetir hasta convergencia o max_iter:
    //    a. Asignar cada punto al centroide más cercano
    //    b. Recalcular centroides como la media de los puntos asignados
    //    c. Verificar convergencia (cambio en centroides < tol)
    // 3. Devolver 1 si éxito, 0 si error
    return 0; // Reemplazar con la implementación
}

Matrix* kmeans_predict(KMeans* model, Matrix* X) {
    // TODO: Implementar la predicción de clusters
    // 1. Crear matriz para almacenar las asignaciones
    // 2. Para cada muestra, encontrar el centroide más cercano
    // 3. Devolver matriz con las asignaciones
    return NULL; // Reemplazar con la implementación
}

double kmeans_inertia(KMeans* model, Matrix* X) {
    // TODO: Implementar el cálculo de inercia
    // 1. Asignar cada punto al centroide más cercano
    // 2. Sumar distancias al cuadrado de cada punto a su centroide
    // 3. Devolver la suma total
    return -1.0; // Reemplazar con la implementación
}

void kmeans_free(KMeans* model) {
    // TODO: Implementar la liberación de memoria
    // 1. Liberar matriz de centroides
    // 2. Liberar la estructura principal
}
